export const hasPermission = (identityAddress, currentUser) => {
  // Simulé pour l'instant, à implémenter plus tard
  return identityAddress === currentUser;
};
