// frontend/src/api/api.js
export const BASE_URL = 'http://localhost:5000';

export const SET_ATTRIBUTE = `${BASE_URL}/identity/attribute/set`;

export const GET_ATTRIBUTE = (identity, key) =>
  `http://localhost:5000/identity/attribute/get/${identity}/${key}`;

// You can add more here:
export const CREATE_HASH = `${BASE_URL}/identity/hash`;
