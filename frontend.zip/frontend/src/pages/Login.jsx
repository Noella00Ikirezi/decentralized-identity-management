import React from 'react';
import './Login.css';
const Login = () => {
  return (
    <div className="login">
      <h2>Connexion</h2>
      <p>Connexion via MetaMask en cours...</p>
    </div>
  );
};

export default Login;
