import React from 'react';
import './Home.css';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="home">
      <h1>Bienvenue sur DIMS</h1>
      <p>Votre identité décentralisée, sécurisée et accessible.</p>
      <div className="home-buttons">
        <Link to="/register" className="btn">Créer mon profil</Link>
        <Link to="/login" className="btn">Se connecter</Link>
      </div>
    </div>
  );
};

export default Home;
