import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { ethers } from 'ethers';
import { GET_ATTRIBUTE } from '../api/api';
import './Profile.css';

const ProfileView = () => {
  const [account, setAccount] = useState('');
  const [profile, setProfile] = useState({
    name: '',
    email: '',
    phone: '',
  });

  const fetchAttribute = async (addr, key) => {
    try {
      const res = await axios.get(GET_ATTRIBUTE(addr, key));
      if (res.data.value) {
        setProfile((prev) => ({
          ...prev,
          [key]: res.data.value,
        }));
      }
    } catch (err) {
      console.warn(`[ATTRIBUTE NOT FOUND] ${key}`, err.message);
    }
  };

  useEffect(() => {
    const init = async () => {
      if (window.ethereum) {
        try {
          const provider = new ethers.providers.Web3Provider(window.ethereum);
          await provider.send('eth_requestAccounts', []);
          const signer = provider.getSigner();
          const userAddress = await signer.getAddress();
          setAccount(userAddress);

          // Récupération des attributs
          await Promise.all([
            fetchAttribute(userAddress, 'name'),
            fetchAttribute(userAddress, 'email'),
            fetchAttribute(userAddress, 'phone'),
          ]);
        } catch (err) {
          console.error('[METAMASK ERROR]', err);
        }
      }
    };

    init();
  }, []);

  return (
    <div className="profile-page">
      <h2 className="profile-title">Aperçu de Mon Profil</h2>

      <p style={{ fontStyle: 'italic', color: '#555' }}>
        Adresse connectée : {account || 'Non connectée'}
      </p>

      <div className="profile-card">
        <div className="profile-field">
          <label className="profile-label">Nom</label>
          <div className="profile-input">{profile.name || 'Non défini'}</div>
        </div>

        <div className="profile-field">
          <label className="profile-label">Email</label>
          <div className="profile-input">{profile.email || 'Non défini'}</div>
        </div>

        <div className="profile-field">
          <label className="profile-label">Téléphone</label>
          <div className="profile-input">{profile.phone || 'Non défini'}</div>
        </div>
      </div>
    </div>
  );
};

export default ProfileView;
