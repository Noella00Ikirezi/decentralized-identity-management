import React from 'react';

const Register = () => {
  return (
    <div className="register">
      <h2>Créer un profil</h2>
      <p>Formulaire à venir...</p>
    </div>
  );
};

export default Register;
