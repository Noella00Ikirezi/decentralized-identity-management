import React, { useState, useEffect } from 'react';
import './Documents.css';
import axios from 'axios';
import { FiUpload } from 'react-icons/fi';

const Documents = () => {
  const [docs, setDocs] = useState([]);

  const fetchDocs = async () => {
    try {
      const { data } = await axios.get('/documents');
      setDocs(data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => { fetchDocs(); }, []);

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('file', file);

    try {
      const { data } = await axios.post('/ipfs/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setDocs((prev) => [...prev, data]);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="documents">
      <label htmlFor="fileInput" className="upload-btn btn">
        <FiUpload size={18} /> Upload
      </label>
      <input id="fileInput" type="file" hidden onChange={handleUpload} />

      {docs.map((d) => (
        <div key={d.cid} className="doc-card">
          <span>{d.name || d.cid}</span>
          <a
            className="btn"
            href={`https://ipfs.io/ipfs/${d.cid}`}
            target="_blank"
            rel="noreferrer"
          >
            Voir
          </a>
        </div>
      ))}
    </div>
  );
};

export default Documents;
