export default {
  transform: {},
  testEnvironment: 'node',
  testMatch: ['**/__tests__/**/*.test.mjs'],
};
